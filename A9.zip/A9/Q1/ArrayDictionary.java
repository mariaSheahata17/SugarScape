import java.util.ArrayList ;
class ArrayDictionary<K extends Comparable<K>, V>{
  //private int index = 0 ;  
  //private int size = 0 ;
  private ArrayList<Pair<K,V>> dic = new ArrayList<Pair<K,V>>() ;
  
  ArrayDictionary(){
  }
    
  public void put(K key, V value){
      
      Pair<K,V> pair = new Pair<K,V>(key ,value );
      int x = 0 ;
      if (dic.size() == 0){
          dic.add(pair) ;
          
      }else{
          // if the key is already in the dic, just update the value
          for (Pair p : dic){
              if(p.key().compareTo(pair.key()) == 0){
                  int j = dic.indexOf(p) ;
                  dic.remove(j);
                  p = new Pair<K,V>(key,pair.value());
                  dic.add(j , p);
                  x= 1 ;
                  break ;
              }    
          }
          
          // if the key is not in the dic, add the pair to the sorted dic
          if (x == 0){
              for(Pair p : dic){
                 if (p.key().compareTo(pair.key()) == 1){
                      int i = dic.indexOf(p) ;
                      dic.add(i , pair);
                      System.out.print(dic.get(i));
                      
                      break;
                      
                 }
                 if(dic.get(dic.size()-1).key().compareTo(pair.key()) == -1){
                      int k = dic.indexOf(p);
                      dic.add(pair);
                      System.out.print(dic.get(k));
                      break;
                      
                 } 
              }
          }
          
      } 
  }
  
  public boolean contains(K key){
      int start = 0 ;
      int end = dic.size()  ;
      // if the size of the dic = 1
      if (start == end -1){
          if (dic.get(0).key().compareTo(key) == 0 ){
              return true ;
          }else{
              return false; 
          }
          
      }
      // if the size is more than 1
      while(end -1 >= start){
          int mid = (end + start) /2 ;
          
          if (dic.get(mid).key().compareTo(key) == 0 ){
              
              return true ;
          }
          else if(dic.get(mid).key().compareTo(key) == -1 ){
              
              start = mid ;
          } 
          else{
              
              end = mid ;
          }
          
          if (mid == dic.size()-1){
              return false ;
          }
      }
            
      return false ;
  }
   
  public V get(K key){
      int start = 0 ;
      int end = dic.size()  ;
      // if the size of the dic = 1
      if (start == end -1){
          if (dic.get(0).key().compareTo(key) == 0 ){
              return dic.get(0).value() ;
          }
      }
      
      if (dic.get(0).key().compareTo(key) == 0){
          return dic.get(0).value() ;
      }
      // if the size is more than 1
      while(end -1 >= start){
          int mid = (end + start) /2 ;
          if(dic.get(mid).key().compareTo(key) == 0 ){
              return dic.get(mid).value() ;
              
          }
          else if(dic.get(mid).key().compareTo(key) == -1 ){
              start = mid ;
          } 
          else{
              end = mid ;
          }

          if (mid == dic.size()-1){
              return null ;
          }

          
      }
      
      return null ;
  }
  
  public V remove(K key){
      System.out.println("The key is:"+ key);
      for(int i = 0 ; i < dic.size() ; i++){
          System.out.println("This is is i :"+ i);
          if (dic.get(i).key().compareTo(key) == 0 ){
              V value = dic.get(i).value() ;
              dic.remove(i);
              return value ;
          }
      }
  
      return null;
  }
  
  public void clear(){
      dic.clear() ;
  }
  
  public int size(){
      return dic.size() ;
  }
  
  public void bulkAdd(ArrayList<Pair<K,V>> data){
      for (int i = 0 ; i < data.size() ; i++){
          put(data.get(i).key() , data.get(i).value()) ;
      }
      
  }
}
