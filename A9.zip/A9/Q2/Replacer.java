import java.util.ArrayList ;
import java.util.Scanner;
// There is a problem in line 61. I tried my best to get the value of the dictionary, but it does'nt work despite in this program. Its working whenever I test the dictionary by itself

public class Replacer{
    
     public static void main(String[] args){
          ArrayDictionary<String,String> dic = new ArrayDictionary<String,String>();
          ArrayList<Pair<String,String>> list = new ArrayList<Pair<String,String>>();
          Pair<Integer, String> p1 = new Pair<Integer, String>(1,"a");
          /*
          list.add( new Pair (new String("Processing"), new String("Java")));
          list.add( new String("list"), new String("dictionary"));
          list.add( new String("slow"), new String("fast"));
          
          dic.bulkAdd(list);
          */
         Scanner scnr = new Scanner(System.in);
         ArrayDictionary<String,String> replace = new ArrayDictionary<String,String>();
         ArrayList<String> keyList = new ArrayList<String>();
         String key ;
         String value ;
         String word ;
         boolean b = true ;
         int t = 0 ;
         
         while(b){
              word = scnr.next();
             if (!(word.equals("DONE"))){
                key = word;
                value = scnr.next();
                replace.put(key , value);
                keyList.add(key);
             }else{
                 b = false ;
             }
             
        
         }
         
         
         System.out.println("Enter the text:");
         ArrayList<String> textList = new ArrayList<String>();
         b = true;
         word = scnr.next();
         while(b){
             if (!(word.equals("DONE"))){
                 //System.out.println(scnr.next());
                 textList.add(word);
                 word = scnr.next();
             }else{
                 b = false ;
             }
         }
         
          for ( int m = 0 ; m < keyList.size() ; m++){
              for (int n = 0 ; n < textList.size() ; n++){
                  if (keyList.get(m).equals(textList.get(n))){
                      textList.remove(n);
                      System.out.println(keyList.get(m));
                      System.out.println(replace.get(keyList.get(m)));
                      textList.add(n,replace.get(keyList.get(m)) );
                      
                  }
              }
             
         }
        
         
         for ( int i = 0 ; i < textList.size() ; i++){
             System.out.print(textList.get(i) + " ");
         }
     }

}
